# API Rate Limiter

A pluggable rate limiting library for Python web frameworks.

## Features

- Fixed Window
- Sliding Window Log
- Sliding Window Counter
- Token Bucket
- Flask Middleware
- FastAPI Middleware

## Installation

```bash
pip install ratelimiter-keshav